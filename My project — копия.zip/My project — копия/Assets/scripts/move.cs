using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerMovement : MonoBehaviour
{
    [Header("��������")]
    public float walkSpeed = 5f;
    public float runSpeed = 8f;
    public float jumpForce = 5f;
    public float mouseSensitivity = 2f;

    [Header("������")]
    public Transform cameraTransform;

    private CharacterController controller;
    private Vector2 moveInput;
    private float xRotation = 0f;
    private Vector3 velocity;
    private bool isGrounded;

    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        controller = GetComponent<CharacterController>();
        if (controller == null)
            controller = gameObject.AddComponent<CharacterController>();

        if (cameraTransform == null)
            cameraTransform = GetComponentInChildren<Camera>().transform;
    }

    void Update()
    {
        // === ������� ����� ===
        Mouse mouse = Mouse.current;
        if (mouse != null)
        {
            Vector2 mouseDelta = mouse.delta.ReadValue();

            float mouseX = mouseDelta.x * mouseSensitivity * 0.01f;
            float mouseY = mouseDelta.y * mouseSensitivity * 0.01f;

            xRotation -= mouseY;
            xRotation = Mathf.Clamp(xRotation, -90f, 90f);
            cameraTransform.localRotation = Quaternion.Euler(xRotation, 0f, 0f);
            transform.Rotate(Vector3.up, mouseX);
        }

        // === �������� WASD ===
        Keyboard keyboard = Keyboard.current;
        if (keyboard != null)
        {
            moveInput = Vector2.zero;
            if (keyboard.wKey.isPressed) moveInput.y = 1;
            if (keyboard.sKey.isPressed) moveInput.y = -1;
            if (keyboard.dKey.isPressed) moveInput.x = 1;
            if (keyboard.aKey.isPressed) moveInput.x = -1;
            if (moveInput.magnitude > 1) moveInput.Normalize();
        }

        float currentSpeed = walkSpeed;
        if (keyboard != null && keyboard.leftShiftKey.isPressed)
            currentSpeed = runSpeed;

        Vector3 move = transform.right * moveInput.x + transform.forward * moveInput.y;
        controller.Move(move * currentSpeed * Time.deltaTime);

        // === ���������� � ������ ===
        isGrounded = controller.isGrounded;
        if (isGrounded && velocity.y < 0)
            velocity.y = -2f;

        if (keyboard != null && keyboard.spaceKey.wasPressedThisFrame && isGrounded)
            velocity.y = Mathf.Sqrt(jumpForce * 2f * 9.81f);

        velocity.y += -9.81f * Time.deltaTime;
        controller.Move(velocity * Time.deltaTime);

        // === ESC ��� ������� ===
        if (keyboard != null && keyboard.escapeKey.wasPressedThisFrame)
        {
            if (Cursor.lockState == CursorLockMode.Locked)
            {
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
            }
            else
            {
                Cursor.lockState = CursorLockMode.Locked;
                Cursor.visible = false;
            }
        }
    }
}